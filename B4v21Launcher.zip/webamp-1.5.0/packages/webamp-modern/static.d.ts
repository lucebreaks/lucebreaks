declare module "*.wsz";
declare module "*.png";
declare module "*.ico";
declare module "*.jpg";
declare module "*.svg";
