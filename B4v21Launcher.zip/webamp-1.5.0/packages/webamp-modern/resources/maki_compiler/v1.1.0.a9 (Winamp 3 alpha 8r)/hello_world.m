#include "lib/std.mi"

System.onScriptLoaded()
{ 
	String response;
	System.messageBox("Hello World", "Hello Title", 1, response);
}