export const VERSIONS = {
  WINAMP_3_ALPHA: "v1.1.0.a9 (Winamp 3 alpha 8r)",
  WINAMP_3_BETA: "v1.1.1.b3 (Winamp 3.0 build 488d)",
  WINAMP_3_FULL: "v1.1.1.b3 (Winamp 3.0 full)",
  WINAMP_5_02: "v1.1.13 (Winamp 5.02)",
  WINAMP_5_66: "v1.2.0 (Winamp 5.66)",
};
