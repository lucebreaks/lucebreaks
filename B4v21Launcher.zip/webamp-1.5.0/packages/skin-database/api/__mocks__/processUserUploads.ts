export const processUserUploads = jest.fn(async () => {
  // Mock
});
