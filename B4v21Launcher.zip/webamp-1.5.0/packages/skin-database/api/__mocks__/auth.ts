export const auth = jest.fn(async () => {
  // Mock
  return "<MOCK_USERNAME>";
});
