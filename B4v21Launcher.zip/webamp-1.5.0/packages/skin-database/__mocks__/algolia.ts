export const searchIndex = {
  partialUpdateObjects: jest.fn(),
};
