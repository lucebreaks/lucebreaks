import XmlObj from "../XmlObj";

export default class ConfigItem extends XmlObj {}
